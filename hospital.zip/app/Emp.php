<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Emp extends Model
{
    //Emp Controller Laravel PHP STEP 2 ..mOHMMADmOATZ

    protected $table = "emps";
}
