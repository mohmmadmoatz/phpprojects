<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class clnper extends Model
{
    protected $table = "clnpers";
}
