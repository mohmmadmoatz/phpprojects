<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class appt extends Model
{
 protected $table = 'appts';
 
    //
}
