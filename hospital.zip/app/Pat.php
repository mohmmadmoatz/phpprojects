<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pat extends Model
{
    protected $table = 'pats';
   // protected $fillable = ['title','body'];
    
}
