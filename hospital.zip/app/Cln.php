<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cln extends Model
{
    //
    protected $table = "clns";
    
}
